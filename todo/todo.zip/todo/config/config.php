<?php 
    define('ROOT_URL', 'http://localhost/phpsandbox/todo/');
    define('DB_HOST','localhost');
    define('DB_USER','id13850610_root');
    define('DB_PASS','Himanshu@007');
    define('DB_NAME','id13850610_todo');

?>