
                
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-12">
                                <?php echo date('Y'); ?> © The Rising Youth Foundation.
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- end main content-->

        </div>
       

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>




<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
        <!-- JAVASCRIPT -->
        <script src="<?= base_url() ?>assets/admin-assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/node-waves/waves.min.js"></script>

        <!-- apexcharts -->
        <script src="<?= base_url() ?>assets/admin-assets/libs/apexcharts/apexcharts.min.js"></script>

        <script src="<?= base_url() ?>assets/admin-assets/libs/slick-slider/slick/slick.min.js"></script>

        <!-- Jq vector map -->
        <script src="<?= base_url() ?>assets/admin-assets/libs/jqvmap/jquery.vmap.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/jqvmap/maps/jquery.vmap.usa.js"></script>

        <script src="<?= base_url() ?>assets/admin-assets/js/pages/dashboard.init.js"></script>

        <script src="<?= base_url() ?>assets/admin-assets/js/app.js"></script>


		

        <!-- Required datatable js -->
        <script src="<?= base_url() ?>assets/admin-assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <!-- Buttons examples -->
        <script src="<?= base_url() ?>assets/admin-assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/jszip/jszip.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/pdfmake/build/pdfmake.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/pdfmake/build/vfs_fonts.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
        <!-- Responsive examples -->
        <script src="<?= base_url() ?>assets/admin-assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
		<script src="<?= base_url() ?>assets/admin-assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
		<script src="<?= base_url() ?>assets/admin-assets/libs/magnific-popup/jquery.magnific-popup.min.js"></script>
		<script src="<?= base_url() ?>assets/admin-assets/js/pages/gallery.init.js"></script>
        <!-- Datatable init js -->
        <script src="<?= base_url() ?>assets/admin-assets/js/pages/datatables.init.js"></script>
        <script src="<?= base_url() ?>assets/admin-assets/js/custom.js"></script>
		<script>
			$(".select2").select2();
		</script>
    </body> 
</html>
